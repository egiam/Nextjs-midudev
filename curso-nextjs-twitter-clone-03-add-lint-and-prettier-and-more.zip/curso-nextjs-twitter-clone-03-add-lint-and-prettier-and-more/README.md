# Clon de Twitter usando NextJS por @midudev

## Empezar a desarrollar

Puedes levantar el entorno de desarrollo con:

```bash
npm run dev
# or
yarn dev
```

Abre [http://localhost:3000](http://localhost:3000) y en tu navegador verás el resultado.

**[👨‍🏫 Todas las clases disponibles en la rama principal.](https://github.com/midudev/curso-nextjs-twitter-clone/blob/master/README.md)**
